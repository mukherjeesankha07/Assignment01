package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;
import testSetup.Testbase;

public class saucelabLogout extends Testbase{

		
	@Then("User logs out")
	public void user_logs_out() throws Throwable {
		
		Thread.sleep(2000); // Wait for 2 secs
		driver.findElement(By.xpath("//button[contains(text(),'Open Menu')]")).click();
		
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[contains(@id,'logout')]")).click();
	    System.out.println("User logged out");
	    
	    driver.quit();
	}

	
}
