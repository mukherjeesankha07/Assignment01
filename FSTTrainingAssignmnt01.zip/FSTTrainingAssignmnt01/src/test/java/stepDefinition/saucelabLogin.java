package stepDefinition;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import io.cucumber.datatable.DataTable;
import io.github.bonigarcia.wdm.WebDriverManager;
import testSetup.Testbase;

public class saucelabLogin extends Testbase{

	
	@Given("user is on saucedemo homepage")
	public void user_is_on_saucedemo_homepage() throws Throwable {
		//WebDriverManager.chromedriver().setup();
		//driver= new ChromeDriver();
		openBrowser();
	    driver.manage().window().maximize();  
	    driver.get("https://www.saucedemo.com");
	    System.out.println("Sauce Demo Page opened");
	}
	
	@Given("user logged in using correct credential")
	public void user_logged_in_using_correct_credential(DataTable dataTable) throws Throwable {
	    
		List<Map<String,String>> data=dataTable.asMaps(String.class, String.class);
				//dataTable.asMap(String.class, String.class);
		    
	    driver.findElement(By.name("user-name")).sendKeys(data.get(0).get("username"));
	    driver.findElement(By.name("password")).sendKeys(data.get(0).get("password"));
	    driver.findElement(By.name("login-button")).click();
	 	    
	   
	    System.out.println("Login Credntial entered");
	}

	
	
}
