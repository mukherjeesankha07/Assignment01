package testRunner;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= "src/test/java/features/Assignment01.feature", 
glue= {"stepDefinition"},
//tags= {"@scenario3"} //Execute Single tag
//tags= {"@Regression","@Sanity"} //AND Condition
//tags= {"@Regression, @Sanity"} // OR Condition
tags= {"@FullScope"}// Entire feature file
//tags= {"@Functional","~@Sanity"} // Run Feature file, excluding Sanity tag
		)

public class testRunner {

}
